import requests
from bs4 import BeautifulSoup
from datetime import datetime

# --- Configuration ---
SOURCES = {
    "Tagesspiegel (Berlin)": "https://www.tagesspiegel.de/berlin/",
    "rbb24 (Berlin/Brandenburg)": "https://www.rbb24.de/",
    "Tip Berlin (Kultur & Events)": "https://www.tip-berlin.de/",
    # "Berliner Zeitung": "https://www.berliner-zeitung.de/" # Added later due to potential complexity
}

# Keywords to prioritize (in German)
KEYWORDS = [
    "kultur", "event", "reise", "neue", "geheimtipp", "ausstellung", 
    "restaurant", "bar", "kiez", "festival", "tipp", "entdecken"
]

# --- Scraping Functions ---

def generic_scraper(url, base_url):
    """A generic scraper that looks for links in the main content area."""
    articles = []
    try:
        response = requests.get(url, timeout=10)
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Look for all links in the body
        for link in soup.find_all('a', href=True):
            href = link['href']
            title = link.get_text(strip=True)
            
            # Filter out short titles, navigation links, and non-article links
            if len(title) > 20 and 'kommentar' not in href and 'login' not in href:
                
                # Construct full URL
                if href.startswith('http'):
                    full_url = href
                elif href.startswith('/'):
                    full_url = base_url + href
                else:
                    continue # Skip relative links that are not root-relative
                
                # Simple check to avoid duplicates and ensure it's a new link
                if full_url not in [a['url'] for a in articles]:
                    articles.append({'title': title, 'url': full_url})
            
            if len(articles) >= 15: # Increase limit slightly
                break
                
    except Exception as e:
        articles.append({'title': f"FEJL ved scraping af {url}: {e}", 'url': ""})
        
    return articles

# Map sources to their specific scraping function
SCRAPERS = {
    "Tagesspiegel (Berlin)": lambda url: generic_scraper(url, "https://www.tagesspiegel.de"),
    "rbb24 (Berlin/Brandenburg)": lambda url: generic_scraper(url, "https://www.rbb24.de"),
    "Tip Berlin (Kultur & Events)": lambda url: generic_scraper(url, "https://www.tip-berlin.de"),
}

# --- Main Logic ---

def filter_and_format(articles):
    """Filters articles based on keywords and formats them."""
    filtered = []
    for article in articles:
        title = article['title'].lower()
        # Simple keyword check
        is_relevant = any(keyword in title for keyword in KEYWORDS)
        
        # Add a tag if a keyword was found
        tag = " 💡" if is_relevant else ""
        
        filtered.append(f"* [{article['title']}{tag}]({article['url']})")
        
    return "\n".join(filtered)

def generate_report():
    """Runs all scrapers and generates the final Markdown report."""
    report = f"# Blogidéer for Berlin - {datetime.now().strftime('%d-%m-%Y')}\n\n"
    report += "Denne rapport er automatisk genereret af din personlige Content Agent.\n"
    report += "💡 indikerer, at titlen indeholder et af dine definerede nøgleord (f.eks. kultur, event, restaurant).\n\n"
    report += "---\n\n"
    
    all_articles = []
    
    for source_name, scraper_func in SCRAPERS.items():
        report += f"## 📰 {source_name}\n\n"
        
        # Get the URL for the source (used for error reporting/reference)
        source_url = SOURCES.get(source_name, "Ukendt URL")
        report += f"Kilde: [{source_url}]({source_url})\n\n"
        
        articles = scraper_func(source_url)
        all_articles.extend(articles)
        
        report += filter_and_format(articles)
        report += "\n\n---\n\n"
        
    # Write the final report to a file
    with open("content_ideas.md", "w", encoding="utf-8") as f:
        f.write(report)

if __name__ == "__main__":
    generate_report()
